from machine import Pin, PWM, ADC, SPI
from ST7735 import TFT
from sysfont import sysfont
import time

# TFT setup
spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=None)
tft = TFT(spi, 21, 20, 22)  # DC, RST, CS
tft.rgb(True)
tft.init_7735(tft.GREENTAB80x160)
tft.fill(TFT.BLACK)

tft.text((0, 00), "RP2040", TFT.RED, sysfont, 2)
tft.text((0, 20), "Servo TEST", TFT.RED, sysfont, 2)
tft.text((0, 40), "Ceyhun Pempeci", TFT.BLUE, sysfont, 2)
tft.text((0, 65), "2025", TFT.GREEN, sysfont, 2)

time.sleep(5)
tft.fill(TFT.BLACK)

# ADC setup for potentiometer (0–3.3V)
adc = ADC(Pin(26))  # ADC0

# Servo setup
servo = PWM(Pin(27))
servo.freq(50)  # 50 Hz = 20 ms period

# Convert angle (0–180) to duty_ns (500 µs to 2500 µs)
def angle_to_duty_ns(angle):
    return int(500_000 + (angle / 180.0) * 2000_000)  # in nanoseconds

# Main loop
while True:
    pot_value = adc.read_u16()  # 0 to 65535
    angle = (pot_value / 65535) * 180  # Scale to 0–180°
    pulse = angle_to_duty_ns(angle)
    servo.duty_ns(pulse)  # Set duty in nanoseconds

    # Display on TFT
    tft.fill(TFT.BLACK)
    tft.text((10, 20), "Angle:", TFT.RED, sysfont, 2)
    tft.text((10, 45), "{:.1f} deg".format(angle), TFT.GREEN, sysfont, 2)

    time.sleep(0.1)